package com.keko_biker.keko_biker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
